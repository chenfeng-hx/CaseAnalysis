const s="/assets/data-bf4b2e0e.svg";export{s as _};
